from .views import scrape_news
from django.urls import path, include


urlpatterns = [
    path('api/headlines/', scrape_news, name='headlines_api'),
]