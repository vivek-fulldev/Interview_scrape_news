import requests
from bs4 import BeautifulSoup
from django.http import JsonResponse

def scrape_news(request):
    url = "https://news.ycombinator.com/"
    response = requests.get(url)
    keyword = request.GET.get('keyword')
    
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        titles = soup.find_all('span', class_="titleline")
        new_headlines_data = []
        headlines_dict = {}
        for idx, title in enumerate(titles):
            title_dict = dict()
            title_dict["title"] = title.text.strip()
            title_dict["link"] = title.a.get('href') if title.a else None
            if idx>=10:
                break
            new_headlines_data.append(title_dict)

        if keyword:
            new_headlines_data = [i for i in new_headlines_data if  i['title'].startswith(keyword.lower())]

            data = {
                'headlines':new_headlines_data
            } 
        else:
            data = {
                'headlines': new_headlines_data
            }



        return JsonResponse(data)
    
    else:
        return JsonResponse({"error": "Failed to retrieve data from Hacker News"})
